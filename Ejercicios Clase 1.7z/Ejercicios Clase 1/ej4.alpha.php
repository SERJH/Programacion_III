<?php

    $i;
    $resultado = 0;
    $contador = 0;

    for($i = 0; $resultado <= 1000; $i++) {

        $resultado += $i;
     
        if ($resultado <= 1000) {

            echo $i . "<br>";
            $contador++;

        } else {

            echo $resultado . "<br>";
            echo $contador;

        }

    }

?>