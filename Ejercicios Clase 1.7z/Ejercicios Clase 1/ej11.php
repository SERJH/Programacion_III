<?php

    $vec = array();
    $vec[1] = 90;
    $vec[30] = 7;
    $vec['e'] = 99;
    $vec['hola'] = 'mundo';

    foreach ($vec as $i) {

        echo $i . "<br>";

    }

?>