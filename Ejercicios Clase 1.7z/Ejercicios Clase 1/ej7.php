<?php

    echo date("l") . ", " . date("d") . " of " . date("F") . " of " . date("Y") . " - " . date();

?>