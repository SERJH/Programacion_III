<?php

    $vec = array();

    for ($i = 0; $i > -1; $i++) {

        if (($i % 2) != 0) {

            array_push($vec, $i);

        }

        if (count($vec) == 10) {

            break;

        }

    }

    for ($i = 0; $i < count($vec); $i++) {

        echo $vec[$i] . "<br>";

    }

    echo "<br>";

    $i = 0;
    while ($i < count($vec)) {

        echo $vec[$i] . "<br>";
        $i++;

    }

    echo "<br>";

    foreach($vec as $i) {

        echo $i . "<br>";

    }

?>