<HTML>

    <body align=center>

        <?php

            #<h1>Hello World!</h1>
            #echo "Hello World!";
            #echo "<br>Santiago";
            $nombre = "Santiago";
            $apellido = "Moran";
            echo $apellido . ', ' .$nombre


        ?>

    </body>

</HTML>   

