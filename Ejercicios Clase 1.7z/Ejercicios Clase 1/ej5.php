<?php

    $a = 2;
    $b = 2;
    $c = 6;

    if (($a < $b && $a > $c || $a < $c && $a > $b)) {

        echo $a;

    } else if ($b < $c && $b > $a || $b < $a && $b > $c) {

        echo $b;

    } else if ($c < $a && $c > $b || $c < $b && $c > $a) {

        echo $c;

    } else {

        echo "No hay valor medio";

    }

?>