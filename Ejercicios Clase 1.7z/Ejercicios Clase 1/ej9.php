<?php

    $vec = array();
    $suma;
    $cantidad = 5;
    $promedio;
    $test = 6;

    for ($i = 0; $i < $cantidad; $i++) {

        $vec[$i] = rand(1, 10);
        $suma += $vec[$i];

    }

    $promedio = $suma / $cantidad;

    if ($promedio < 6) {

        echo "Menor a 6";

    } else if ($promedio > 6) {

        echo "Mayor a 6";

    } else {

        echo "Igual a 6";

    }

?>