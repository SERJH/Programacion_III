<?php

    $num = 34;
    $uno = "uno";
    $dos = "dos";
    $tres = "tres";
    $cuatro = "cuatro";
    $cinco = "cinco";
    $seis = "seis";
    $siete = "siete";
    $ocho = "ocho";
    $nueve = "nueve";
    $veinte = "veint";
    $treinta = "treinta";
    $cuarenta = "cuarenta";
    $cincuenta = "cincuenta";
    $sesenta = "sesenta";
    
    switch ($num) {

        case $num >= 20 && $num < 30:

            

    }

?>