<?php

    $lapicera1 = array('Color' => 'Negro', 'Marca' => 'Filgo', 'Trazo' => 'Fino', 'Precio' => 10);
    $lapicera2 = array('Color' => 'Rojo', 'Marca' => 'Filgo', 'Trazo' => 'Grueso', 'Precio' => 8);
    $lapicera3 = array('Color' => 'Azul', 'Marca' => 'Faber Castell', 'Trazo' => 'Fino', 'Precio' => 12);
    
    var_dump($lapicera1);
    echo '<br>';
    var_dump($lapicera2);
    echo '<br>';
    var_dump($lapicera3);

?>