<?php

    $vec1 = array();
    $vec2 = array();
    $vec3 = array();
    $vecFinal;

    array_push($vec1, "Perro");
    array_push($vec1, "Gato");
    array_push($vec1, "Ratón");
    array_push($vec1, "Araña");
    array_push($vec1, "Mosca");

    array_push($vec2, "1986");
    array_push($vec2, "1996");
    array_push($vec2, "2015");
    array_push($vec2, "78");
    array_push($vec2, "86");

    array_push($vec3, "PHP");
    array_push($vec3, "MySQL");
    array_push($vec3, "HTML5");
    array_push($vec3, "TypeScript");
    array_push($vec3, "AJAX");

    $vecFinal = array_merge($vec1, $vec2, $vec3);

    var_dump($vecFinal);

?>