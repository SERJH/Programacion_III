<?php

    $vec1 = array();
    $vec2 = array();
    $vec3 = array();

    array_push($vec1, "Perro");
    array_push($vec1, "Gato");
    array_push($vec1, "Ratón");
    array_push($vec1, "Araña");
    array_push($vec1, "Mosca");

    array_push($vec2, "1986");
    array_push($vec2, "1996");
    array_push($vec2, "2015");
    array_push($vec2, "78");
    array_push($vec2, "86");

    array_push($vec3, "PHP");
    array_push($vec3, "MySQL");
    array_push($vec3, "HTML5");
    array_push($vec3, "TypeScript");
    array_push($vec3, "AJAX");

    $vecIndexado = array();
    array_push($vecIndexado, $vec1);
    array_push($vecIndexado, $vec2);
    array_push($vecIndexado, $vec3);

    $vecAsociado = array("Primera" => $vec1, "Segunda" => $vec2, "Tercera" => $vec3);

    #var_dump($vecIndexado);
    #var_dump($vecAsociado);

    foreach ($vecIndexado as $i) {

        echo $i;
        foreach ($i as $j) {

            echo $j . '<br';

        }

    }

?>