<?php

    $operador = '/';
    $op1 = 54;
    $op2 = 2;

    if ($operador == '+') {

        echo $op1 + $op2;

    } else if ($operador == '-') {

        echo $op1 - $op2;

    } else if ($operador == '*') {

        echo $op1 * $op2;

    } else if ($operador == '/') {

        echo $op1 / $op2;

    }

?>