<?php

    $i;
    $resultado = 1;

    for($i = 2; $i <= 1000; $i++) {

        $resultado += $i;
        $i = $resultado;
        
        echo $resultado . "<br>";

    }

?>