<?php

    $x = -3;
    $y = 15;
    echo $x + $y;

?>