<?php

function Ejercicio25() {

    $cantUno = 0;
    $cantDos = 0;
    $cantTres = 0;
    $cantCuatro = 0;
    $cantMasDeCuatro = 0;

    $path = "archivos/ej25.txt";

    $archivo = fopen($path, "w+");
    fwrite($archivo, "aaaaaa aa a aaaa");
    fseek($archivo, 0);

    $contenido = fread($archivo, filesize($path));
    echo $contenido;
    $palabras = split(" ", $contenido);

    echo $palabras[2] . "<br>";

    foreach($palabras as $palabra) {

        $cantPalabra = strlen($palabra);
    
        switch ($cantPalabra) {

            case 1:
                $cantUno++;
                break;
            case 2:
                $cantDos++;
                break;
            case 3:
                $cantTres++;
                break;
            case 4:
                $cantCuatro++;
                break;
            default:
                $cantMasDeCuatro++;
                break;

        }

    }

    echo "Cantidad de uno: " . $cantUno . "<br>" .
        "Cantidad de dos: " . $cantDos . "<br>" .
        "Cantidad de tres: " . $cantTres . "<br>" .
        "Cantidad de cuatro: " . $cantCuatro . "<br>" .
        "Cantidad de cuatro o mas: " . $cantMasDeCuatro . "<br><br><br>";

        echo "<table border='solid'>

        <tr>
            <td> Una </td>
            <td> Dos </td>
            <td> Tres </td>
            <td> Cuatro </td>
            <td> + Cuatro </td>
        </tr>
        <tr>
            <td> $cantUno </td>
            <td> $cantDos </td>
            <td> $cantTres </td>
            <td> $cantCuatro </td>
            <td> $cantMasDeCuatro </td>
        </tr>

</table>";

}

Ejercicio25();



?>

